#include <stdio.h>

#define FW_Version 0X38 // Firmware Version

/* Programmability Options */
#define TAG 1        // If TAG 1 programming for TAG else for Base Station
#define USE_UART 0   // Use UART for Debug (Base Station)

#define OTAP 0       // Over The AIR Programmability
#define SENSORS 0    // HTS Sensor

#define UART_DEBUG 0
#define DEBUG 1      // IF TAG = 1 --> USE ONLY WHEN BATTERY and NO Harvester
                     // IF TAG = 0 --> Feedback of error Functions
#define MANUFATURE_ID_LSB 0x00
#define MANUFATURE_ID_MSB 0x30
#define RF_CONTROL 1
#define FROM_FLASH 1


#define NPK_TAG 0x0A // Number of (N-1) bytes of the TAG ADVERTISING DATA PACKET
#define NPK_BS  0x0A // Number of (N-1) bytes of the BS  ADVERTISING DATA PACKET
#define NPK_APP 0x08 // Number of (N-1) bytes of the APP ADVERTISING DATA PACKET

#define RTPS 20  /* Radio Transmission Period in Seconds 
                    Enlapsed time between TAG Transmissions
                    This Value is overridden by the Flash 
                 */

#define NTB  6   /* Number of Transmitted Beacons 
                    This Value is overridden by the Flash 
                 */

#define PREAMBLE (uint8_t)(100)
#define PREAMBLE_APP_TAG 200 
#define PREAMBLE_APP_BS 150                   
#define CRC PREAMBLE^RTPS^NTB
#define CRC1 PREAMBLE^LIGHT_THRESHOLD^WB_THRESHOLD^DARK_THRESHOLD
#define TEMPERATURE 0
#define HUMIDITY 0
#define TADV_MSB 0
#define TADV_LSB 0

void My_Error_Report(char *str, char ret);
